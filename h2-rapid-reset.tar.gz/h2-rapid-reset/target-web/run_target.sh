#!/bin/bash
set -e
rm -f /home/ubuntu/target-metrics.json
echo "target_started=yes"
exec python3 /home/ubuntu/target_server.py
