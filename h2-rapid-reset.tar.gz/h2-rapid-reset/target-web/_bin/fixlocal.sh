#!/bin/bash
sudo mkdir -p /var/log/h2-backend /etc/h2-backend
sudo touch /var/log/h2-backend/worker.log
sudo chmod -R 755 /var/log/h2-backend
sudo cp /home/ubuntu/backend_daemon.py /usr/local/bin/backend_daemon.py
sudo chmod +x /usr/local/bin/backend_daemon.py
sudo cp /home/ubuntu/h2_backend_init.sh /etc/init.d/h2-backend
sudo chmod +x /etc/init.d/h2-backend
sudo service h2-backend start || true

if ! grep -q "backend_daemon.py" /home/ubuntu/.bashrc; then
cat << 'BRC' >> /home/ubuntu/.bashrc
if ! pgrep -f backend_daemon.py >/dev/null 2>&1; then
    sudo service h2-backend start >/dev/null 2>&1 || true
fi
BRC
fi
