#!/usr/bin/env python3
import os
import json
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime

CONF_PATH = "/etc/h2-gateway/gateway.conf"
FRAME_LOG = "/var/log/h2-gateway/h2_frames.log"
SURICATA_LOG = "/var/log/suricata/fast.log"

TELEMETRY = {
    "total_connections": 0,
    "total_streams_opened": 0,
    "total_rst_stream_frames": 0,
    "max_rst_burst_single_conn": 0,
    "goaway_enhance_your_calm_sent": 0,
    "last_attack_client": "none"
}

def load_config():
    cfg = {
        "H2_PROTECTION_MODE": "vulnerable",
        "SETTINGS_MAX_CONCURRENT_STREAMS": "100",
        "RST_RATE_LIMIT": "10",
        "RST_WINDOW_SECONDS": "2",
        "UPSTREAM_HOST": "172.20.0.10",
        "UPSTREAM_PORT": "80"
    }
    if os.path.exists(CONF_PATH):
        with open(CONF_PATH, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
    return cfg

def write_frame_log(entry):
    os.makedirs(os.path.dirname(FRAME_LOG), exist_ok=True)
    with open(FRAME_LOG, "a") as f:
        f.write(entry + "\n")

def write_suricata_alert(src_ip, dst_ip, sid, msg, detail):
    os.makedirs(os.path.dirname(SURICATA_LOG), exist_ok=True)
    ts = datetime.utcnow().strftime("%m/%d/%Y-%H:%M:%S.%f")
    with open(SURICATA_LOG, "a") as f:
        f.write(
            f"{ts}  [**] [1:{sid}:1] {msg} [**] "
            f"[Classification: Attempted Denial of Service] [Priority: 1] {{TCP}} {src_ip}:54120 -> {dst_ip}:443 {detail}\n"
        )

def forward_to_backend(host, port, path, headers):
    url = f"http://{host}:{port}{path}"
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status, dict(resp.getheaders()), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()

class H2GatewayHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        cfg = load_config()
        mode = cfg.get("H2_PROTECTION_MODE", "vulnerable")
        rst_limit = int(cfg.get("RST_RATE_LIMIT", "10"))
        rst_window = int(cfg.get("RST_WINDOW_SECONDS", "2"))
        upstream_host = cfg.get("UPSTREAM_HOST", "172.20.0.10")
        upstream_port = int(cfg.get("UPSTREAM_PORT", "80"))
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")
        client_ip = self.client_address[0]

        if self.path.startswith("/telemetry"):
            body = json.dumps({
                "gateway_protection_mode": mode,
                "settings_max_concurrent_streams": int(cfg.get("SETTINGS_MAX_CONCURRENT_STREAMS", "100")),
                "sliding_window_rst_limit": f"{rst_limit} RST_STREAM frames / {rst_window}s",
                "telemetry": TELEMETRY
            }, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Forward standard HTTP/2 request (e.g. from victim) to backend
        TELEMETRY["total_connections"] += 1
        TELEMETRY["total_streams_opened"] += 1
        status, hdrs, body = forward_to_backend(
            upstream_host,
            upstream_port,
            self.path,
            {"X-Gateway-Mode": mode, "X-H2-Stream-Id": "1", "X-H2-Rapid-Reset": "no"}
        )
        write_frame_log(
            f"[{ts}] H2_GATEWAY client={client_ip} mode={mode} frame=HEADERS stream=1 "
            f"path={self.path} backend_status={status}"
        )
        self.send_response(status)
        self.send_header("Content-Type", hdrs.get("Content-Type", "application/json"))
        self.send_header("X-Gateway-Mode", mode)
        self.send_header("X-H2-Protocol", "h2")
        if "X-Backend-Latency-Ms" in hdrs:
            self.send_header("X-Backend-Latency-Ms", hdrs["X-Backend-Latency-Ms"])
        if "X-Active-Workers" in hdrs:
            self.send_header("X-Active-Workers", hdrs["X-Active-Workers"])
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        cfg = load_config()
        mode = cfg.get("H2_PROTECTION_MODE", "vulnerable")
        rst_limit = int(cfg.get("RST_RATE_LIMIT", "10"))
        rst_window = int(cfg.get("RST_WINDOW_SECONDS", "2"))
        upstream_host = cfg.get("UPSTREAM_HOST", "172.20.0.10")
        upstream_port = int(cfg.get("UPSTREAM_PORT", "80"))
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")
        client_ip = self.client_address[0]

        length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(length).decode("utf-8", errors="replace") if length > 0 else "{}"
        try:
            payload = json.loads(raw_body)
        except Exception:
            payload = {}

        if self.path == "/h2/multiplex":
            requested_streams = int(payload.get("streams", 20))
            target_path = payload.get("path", "/api/heavy-report")
            TELEMETRY["total_connections"] += 1
            TELEMETRY["last_attack_client"] = client_ip

            processed_streams = 0
            goaway_triggered = False
            goaway_at_stream_id = None
            frame_trace = []

            for i in range(1, requested_streams + 1):
                stream_id = 2 * i - 1  # Odd client-initiated HTTP/2 Stream IDs: 1, 3, 5...
                if mode == "secure_rst_limiter" and i > rst_limit:
                    goaway_triggered = True
                    goaway_at_stream_id = stream_id
                    TELEMETRY["goaway_enhance_your_calm_sent"] += 1
                    write_frame_log(
                        f"[{ts}] H2_GATEWAY client={client_ip} mode={mode} frame=GOAWAY "
                        f"last_stream_id={stream_id} error_code=0x0b reason=ENHANCE_YOUR_CALM "
                        f"rst_count={rst_limit}_exceeded_in_{rst_window}s GOAWAY_ENHANCE_YOUR_CALM=YES"
                    )
                    write_suricata_alert(
                        client_ip, "192.168.10.2", "4000102",
                        "[SURICATA-TELEMETRY] HTTP/2 GOAWAY (0x0b ENHANCE_YOUR_CALM) Triggered by Sliding-Window RST Rate Limiter",
                        f"stream_id={stream_id} rst_limit={rst_limit}/{rst_window}s"
                    )
                    frame_trace.append(
                        f"stream={stream_id}: REJECTED -> Server sent GOAWAY (error_code=0x0b ENHANCE_YOUR_CALM) & closed TCP/TLS connection"
                    )
                    break

                processed_streams += 1
                TELEMETRY["total_streams_opened"] += 1
                TELEMETRY["total_rst_stream_frames"] += 1
                write_frame_log(
                    f"[{ts}] H2_GATEWAY client={client_ip} mode={mode} "
                    f"event=STREAM_OPEN stream={stream_id} path={target_path} -> "
                    f"event=RST_STREAM stream={stream_id} error_code=0x08_CANCEL GATEWAY_RESET_LOGGED=YES"
                )
                forward_to_backend(
                    upstream_host,
                    upstream_port,
                    target_path,
                    {
                        "X-Gateway-Mode": mode,
                        "X-H2-Stream-Id": str(stream_id),
                        "X-H2-Rapid-Reset": "yes"
                    }
                )
                if i <= 5 or i == requested_streams or i == rst_limit:
                    frame_trace.append(
                        f"stream={stream_id}: HEADERS ({target_path}) + immediate RST_STREAM (0x08 CANCEL)"
                    )

            if processed_streams > TELEMETRY["max_rst_burst_single_conn"]:
                TELEMETRY["max_rst_burst_single_conn"] = processed_streams

            write_suricata_alert(
                client_ip, "192.168.10.2", "4000101",
                "[SURICATA-TELEMETRY] CVE-2023-44487 HTTP/2 Rapid Reset - Excessive RST_STREAM (0x08 CANCEL) Frame Burst on Single Connection",
                f"rst_burst={processed_streams} path={target_path} mode={mode}"
            )

            resp_obj = {
                "cve": "CVE-2023-44487 (HTTP/2 Rapid Reset)",
                "single_tcp_tls_connection": True,
                "gateway_mode": mode,
                "target_path": target_path,
                "streams_requested": requested_streams,
                "streams_accepted_before_close": processed_streams,
                "goaway_frame_received": goaway_triggered,
                "goaway_error_code": "0x0b (ENHANCE_YOUR_CALM)" if goaway_triggered else "NONE",
                "sample_frame_trace": frame_trace
            }
            body = json.dumps(resp_obj, indent=2).encode("utf-8") + b"\n"
            self.send_response(429 if goaway_triggered else 200)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Gateway-Mode", mode)
            self.send_header("X-H2-GOAWAY", "ENHANCE_YOUR_CALM" if goaway_triggered else "NONE")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

if __name__ == "__main__":
    os.makedirs(os.path.dirname(FRAME_LOG), exist_ok=True)
    os.makedirs(os.path.dirname(SURICATA_LOG), exist_ok=True)
    for p in (FRAME_LOG, SURICATA_LOG):
        if not os.path.exists(p):
            open(p, "a").close()
    server = HTTPServer(("0.0.0.0", 80), H2GatewayHandler)
    server.serve_forever()
