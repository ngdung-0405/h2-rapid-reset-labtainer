#!/usr/bin/env python3
p="/home/ubuntu/rapid-reset.rules"
text=open(p).read() if __import__("os").path.exists(p) else ""
print("rule_created=" + ("yes" if "rapid_reset_simulation" in text and "threshold=10" in text else "no"))
