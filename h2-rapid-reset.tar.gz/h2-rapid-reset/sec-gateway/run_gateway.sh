#!/bin/bash
set -e
cd /home/ubuntu
rm -f h2-gateway-metrics.json gateway-events.log gateway.crt gateway.key
openssl req -x509 -newkey rsa:2048 -nodes -days 1 \
  -keyout gateway.key -out gateway.crt -subj "/CN=portal.lab" >/dev/null 2>&1
echo "gateway_started=yes"
echo "GATEWAY_MODE=vulnerable"
exec env GATEWAY_MODE=vulnerable python3 /home/ubuntu/h2_gateway.py
