#!/usr/bin/env python3
from pathlib import Path

print("=== TOM TAT LUONG LAB 03 ===")

state = Path("/home/ubuntu/cache-state.txt")
events = Path("/home/ubuntu/gateway-events.log")

if state.exists() and state.read_text().strip():
    print("\n[1] TRANG THAI CACHE")
    print(state.read_text())
else:
    print("\n[1] Cache chua co request nao.")

if events.exists() and events.read_text().strip():
    print("[2] NHAT KY REQUEST QUA GATEWAY")
    print(events.read_text())
else:
    print("[2] Chua co request nao qua gateway.")

print("[3] Cach doc ket qua:")
print(" - MISS + cookie YES: attacker da dau doc cache.")
print(" - HIT + cookie YES : victim nhan response da bi dau doc.")
print(" - HIT + cookie NO  : cache sach, victim an toan.")
