#!/bin/bash
chmod +x /home/ubuntu/*.py
chown -R ubuntu:ubuntu /home/ubuntu
