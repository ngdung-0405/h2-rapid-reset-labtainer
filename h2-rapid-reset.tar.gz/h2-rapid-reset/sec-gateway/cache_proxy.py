#!/usr/bin/env python3
import re
import socket
import socketserver
from datetime import datetime

TARGET_HOST = "172.20.0.10"
TARGET_PORT = 80
CACHE = {}

EVENT_LOG = "/home/ubuntu/gateway-events.log"
STATE_FILE = "/home/ubuntu/cache-state.txt"

def read_headers(sock):
    data = b""
    sock.settimeout(5)
    while b"\r\n\r\n" not in data and len(data) < 65535:
        chunk = sock.recv(4096)
        if not chunk:
            break
        data += chunk
    return data

def read_all(sock):
    data = b""
    sock.settimeout(5)
    while True:
        try:
            chunk = sock.recv(4096)
        except socket.timeout:
            break
        if not chunk:
            break
        data += chunk
    return data

def get_cache_key(request):
    first_line = request.split(b"\r\n", 1)[0]
    parts = first_line.split(b" ")

    if len(parts) < 2:
        return b"/invalid"

    path = parts[1]

    # Cố ý yếu: chỉ lấy vi/en/fr ở đầu tham số lang.
    match = re.search(br"(?:[?&]lang=)([A-Za-z]{2})", path)
    if match:
        return b"/page?lang=" + match.group(1).lower()

    return path

def add_cache_header(response, cache_result):
    header, divider, body = response.partition(b"\r\n\r\n")
    if not divider:
        return response

    return (
        header
        + b"\r\nX-Lab-Cache: "
        + cache_result.encode()
        + divider
        + body
    )

def update_state(key, result, request, response):
    request_text = request.split(b"\r\n", 1)[0].decode("iso-8859-1", "replace")
    contains_cookie = b"Set-Cookie: admin_access=true" in response

    with open(STATE_FILE, "w", encoding="utf-8") as f:
        f.write("=== LAB 03 CACHE STATE ===\n")
        f.write("Time: %s\n" % datetime.utcnow().isoformat())
        f.write("Last request: %s\n" % request_text)
        f.write("Normalized cache key: %s\n" % key.decode("iso-8859-1", "replace"))
        f.write("Cache result: %s\n" % result)
        f.write("Cached response contains admin cookie: %s\n" % (
            "YES" if contains_cookie else "NO"
        ))
        f.write("Number of cache entries: %d\n" % len(CACHE))

    with open(EVENT_LOG, "a", encoding="utf-8") as f:
        f.write("%s result=%s key=%s request=%s\n" % (
            datetime.utcnow().isoformat(),
            result,
            key.decode("iso-8859-1", "replace"),
            request_text
        ))

class ReverseProxy(socketserver.BaseRequestHandler):
    def handle(self):
        request = read_headers(self.request)
        if not request:
            return

        key = get_cache_key(request)

        if key in CACHE:
            response = CACHE[key]
            result = "HIT"
            print("[Gateway] CACHE HIT :", key.decode(), flush=True)
        else:
            print("[Gateway] CACHE MISS:", key.decode(), flush=True)
            print("[Gateway] Forward request -> target-web", flush=True)

            with socket.create_connection((TARGET_HOST, TARGET_PORT), timeout=5) as upstream:
                upstream.sendall(request)
                response = read_all(upstream)

            CACHE[key] = response
            result = "MISS"

            if b"Set-Cookie: admin_access=true" in response:
                print("[Gateway] CANH BAO: Cache da luu response chua admin_access=true", flush=True)

        update_state(key, result, request, response)
        self.request.sendall(add_cache_header(response, result))

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True

open(EVENT_LOG, "w").close()
open(STATE_FILE, "w").close()

print("SEC_GATEWAY_CACHE_STARTED=yes", flush=True)
print("Gateway dang nghe tai 192.168.10.2:80", flush=True)
Server(("0.0.0.0", 80), ReverseProxy).serve_forever()
