#!/bin/bash
set -e
echo "attacker_started=yes"
exec python3 /home/ubuntu/attacker_client.py
