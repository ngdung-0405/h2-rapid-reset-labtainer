#!/usr/bin/env python3
import json
try:
    d=json.load(open("/home/ubuntu/h2-gateway-metrics.json"))
except Exception:
    d={}
print("rapid_reset_detected=" + ("yes" if d.get("stream_resets",0)>=10 else "no"))
