#!/usr/bin/env python3
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

METRICS = "/home/ubuntu/target-metrics.json"
LOCK = threading.RLock()
JOBS = {}
CANCELLED = set()

state = {
    "slow_started": 0,
    "slow_cancelled": 0,
    "slow_completed": 0,
    "active": 0,
    "peak_active": 0
}

def save():
    with LOCK:
        with open(METRICS, "w") as f:
            json.dump(state, f)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[target] " + fmt % args, flush=True)

    def send_json(self, code, payload):
        raw = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        global state
        parsed = urlsplit(self.path)
        query = parse_qs(parsed.query)

        if parsed.path == "/api/catalog":
            self.send_json(200, {
                "service": "target-web",
                "items": ["LAB_BOOK", "LAB_PEN"],
                "message": "Normal HTTP/2 request completed"
            })
            return

        if parsed.path == "/lab/cancel":
            sid = query.get("stream_id", ["unknown"])[0]
            with LOCK:
                CANCELLED.add(sid)
                if sid in JOBS:
                    JOBS[sid].set()
            print(f"[target] cancel received stream={sid}", flush=True)
            self.send_json(200, {"cancel_received": sid})
            return

        if parsed.path == "/lab/slow-read":
            sid = query.get("stream_id", ["unknown"])[0]
            event = threading.Event()

            with LOCK:
                JOBS[sid] = event
                state["slow_started"] += 1
                state["active"] += 1
                state["peak_active"] = max(state["peak_active"], state["active"])
                if sid in CANCELLED:
                    event.set()
                save()

            print(f"[target] slow-read begin stream={sid}", flush=True)
            was_cancelled = event.wait(timeout=0.50)

            with LOCK:
                state["active"] -= 1
                JOBS.pop(sid, None)
                if was_cancelled:
                    state["slow_cancelled"] += 1
                    result = "cancelled"
                else:
                    state["slow_completed"] += 1
                    result = "completed"
                save()

            print(f"[target] slow-read {result} stream={sid}", flush=True)
            self.send_json(200, {"stream_id": sid, "result": result})
            return

        self.send_json(404, {"error": "not found"})

save()
print("target_started=yes", flush=True)
print("TARGET_H2_BACKEND_READY=yes", flush=True)

ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
