#!/usr/bin/env python3
import json
p="/home/ubuntu/h2-gateway-metrics.json"
try:
    d=json.load(open(p))
except Exception:
    d={}
print("=== H2 GATEWAY METRICS ===")
for k,v in d.items():
    print(f"{k}: {v}")
print("gateway_reset_logged=" + ("yes" if d.get("stream_resets",0)>0 else "no"))
print("secure_limit_enforced=" + ("yes" if d.get("secure_limit_triggered") else "no"))
