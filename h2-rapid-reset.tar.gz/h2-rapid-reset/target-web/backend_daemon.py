#!/usr/bin/env python3
import os
import json
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime

LOG_DIR = "/var/log/h2-backend"
WORKER_LOG = os.path.join(LOG_DIR, "worker.log")

STATE = {
    "max_workers": 16,
    "active_orphan_workers": 0,
    "total_catalog_requests": 0,
    "total_heavy_spawned": 0,
    "total_client_cancelled": 0,
    "overload_events": 0
}

def write_log(entry):
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(WORKER_LOG, "a") as f:
        f.write(entry + "\n")

class BackendHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        ts = datetime.utcnow().strftime("%d/%b/%Y:%H:%M:%S +0000")
        parsed = urllib.parse.urlparse(self.path)
        gw_mode = self.headers.get("X-Gateway-Mode", "vulnerable")
        stream_id = self.headers.get("X-H2-Stream-Id", "1")
        rst_flag = self.headers.get("X-H2-Rapid-Reset", "no")

        # Auto-release orphan workers when gateway switches to secure_rst_limiter
        if gw_mode == "secure_rst_limiter":
            STATE["active_orphan_workers"] = 0

        if parsed.path == "/api/catalog":
            STATE["total_catalog_requests"] += 1
            if gw_mode == "vulnerable" and STATE["active_orphan_workers"] >= STATE["max_workers"]:
                STATE["overload_events"] += 1
                write_log(
                    f"[{ts}] TARGET_BACKEND path=/api/catalog status=503 gw_mode={gw_mode} "
                    f"active_workers={STATE['active_orphan_workers']}/{STATE['max_workers']} "
                    f"VICTIM_DOS_IMPACTED=YES"
                )
                body = json.dumps({
                    "error": "503_SERVICE_UNAVAILABLE",
                    "reason": "BACKEND_WORKER_POOL_EXHAUSTED_BY_RAPID_RESET",
                    "active_workers": f"{STATE['active_orphan_workers']}/{STATE['max_workers']}",
                    "simulated_queue_latency_ms": 1450,
                    "gateway_mode": gw_mode
                }, indent=2).encode("utf-8") + b"\n"
                self.send_response(503)
                self.send_header("Content-Type", "application/json")
                self.send_header("X-Backend-Latency-Ms", "1450")
                self.send_header("X-Active-Workers", f"{STATE['active_orphan_workers']}/{STATE['max_workers']}")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            status_tag = "VICTIM_STABLE_AFTER_FIX=YES" if gw_mode == "secure_rst_limiter" else "VICTIM_BASELINE_OK=YES"
            write_log(
                f"[{ts}] TARGET_BACKEND path=/api/catalog status=200 gw_mode={gw_mode} "
                f"active_workers=1/{STATE['max_workers']} {status_tag}"
            )
            body = json.dumps({
                "service": "target-web",
                "endpoint": "/api/catalog",
                "items": ["LAB_BOOK", "LAB_PEN", "PTIT_SECURITY_TOKEN"],
                "gateway_mode": gw_mode,
                "active_workers": f"1/{STATE['max_workers']}",
                "latency_ms": 8.4,
                "message": "Normal HTTP/2 request completed successfully"
            }, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Backend-Latency-Ms", "8.4")
            self.send_header("X-Active-Workers", f"1/{STATE['max_workers']}")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        elif parsed.path in ("/api/heavy-report", "/lab/slow-read"):
            STATE["total_heavy_spawned"] += 1
            if rst_flag == "yes":
                STATE["total_client_cancelled"] += 1
                if gw_mode == "vulnerable":
                    STATE["active_orphan_workers"] = min(STATE["max_workers"], STATE["active_orphan_workers"] + 1)
                write_log(
                    f"[{ts}] TARGET_BACKEND path={parsed.path} stream={stream_id} "
                    f"action=WORKER_SPAWNED_THEN_RST_CANCELLED "
                    f"active_workers={STATE['active_orphan_workers']}/{STATE['max_workers']} "
                    f"TARGET_REQUEST_CANCELLED=YES"
                )
            body = json.dumps({
                "stream_id": stream_id,
                "path": parsed.path,
                "worker_cancelled_by_rst": (rst_flag == "yes"),
                "active_orphan_workers": STATE["active_orphan_workers"]
            }).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        elif parsed.path == "/metrics":
            body = json.dumps(STATE, indent=2).encode("utf-8") + b"\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        else:
            body = b'{"status":"h2-backend online","endpoints":["/api/catalog","/api/heavy-report","/metrics"]}\n'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

if __name__ == "__main__":
    os.makedirs(LOG_DIR, exist_ok=True)
    if not os.path.exists(WORKER_LOG):
        open(WORKER_LOG, "a").close()
    server = HTTPServer(("0.0.0.0", 80), BackendHandler)
    server.serve_forever()
