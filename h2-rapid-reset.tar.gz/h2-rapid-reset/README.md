# HTTP/2 Rapid Reset – Labtainer

Lab mô phỏng an toàn HTTP/2 Rapid Reset trong mạng Labtainer.

## Mục tiêu

- Quan sát HTTP/2 stream được mở rồi hủy bằng `RST_STREAM`.
- Theo dõi log reset tại `sec-gateway` và request bị hủy tại `target-web`.
- Bật rate-limit reset stream, nhận `GOAWAY ENHANCE_YOUR_CALM`.
- Xác nhận `victim` vẫn truy cập `/api/catalog` bình thường sau khi vá.

Giới hạn tối đa 50 stream mỗi lần thử nghiệm. Các endpoint đều chỉ dùng dữ liệu mẫu.

## Chạy lab

```bash
rebuild -f h2-rapid-reset
labtainer -r h2-rapid-reset
Thứ tự thực hiện:
1. target-web:   ./run_target.sh
2. sec-gateway:  ./run_gateway.sh
3. victim:       python3 ~/victim_client.py → /api/catalog
4. attacker-web: ./run_attacker.sh → 20 → /lab/slow-read
5. sec-gateway:  Ctrl+C, rồi ./run_gateway_secure.sh
6. attacker-web: ./run_attacker.sh → 26 → /lab/slow-read
7. victim:       python3 ~/victim_client.py → /api/catalog
8. student:      checkwork
Kết quả cuối cùng cần có:
Y - completed_lab
cat > "$LABPATH/README.md" <<'EOF'
# HTTP/2 Rapid Reset – Labtainer

Lab mô phỏng an toàn HTTP/2 Rapid Reset trong mạng Labtainer.

## Mục tiêu

- Quan sát HTTP/2 stream được mở rồi hủy bằng `RST_STREAM`.
- Theo dõi log reset tại `sec-gateway` và request bị hủy tại `target-web`.
- Bật rate-limit reset stream, nhận `GOAWAY ENHANCE_YOUR_CALM`.
- Xác nhận `victim` vẫn truy cập `/api/catalog` bình thường sau khi vá.

Giới hạn tối đa 50 stream mỗi lần thử nghiệm. Các endpoint đều chỉ dùng dữ liệu mẫu.

## Chạy lab

```bash
rebuild -f h2-rapid-reset
labtainer -r h2-rapid-reset
Thứ tự thực hiện:
1. target-web:   ./run_target.sh
2. sec-gateway:  ./run_gateway.sh
3. victim:       python3 ~/victim_client.py → /api/catalog
4. attacker-web: ./run_attacker.sh → 20 → /lab/slow-read
5. sec-gateway:  Ctrl+C, rồi ./run_gateway_secure.sh
6. attacker-web: ./run_attacker.sh → 26 → /lab/slow-read
7. victim:       python3 ~/victim_client.py → /api/catalog
8. student:      checkwork
Kết quả cuối cùng cần có:
Y - completed_lab
