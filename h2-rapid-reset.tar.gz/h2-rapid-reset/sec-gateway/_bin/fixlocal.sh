#!/bin/bash
sudo mkdir -p /var/log/h2-gateway /var/log/suricata /etc/h2-gateway /etc/suricata/rules
sudo touch /var/log/h2-gateway/h2_frames.log /var/log/suricata/fast.log
sudo chmod -R 755 /var/log/h2-gateway /var/log/suricata
sudo cp /home/ubuntu/h2_gateway_daemon.py /usr/local/bin/h2_gateway_daemon.py
sudo chmod +x /usr/local/bin/h2_gateway_daemon.py
sudo cp /home/ubuntu/h2_gateway_init.sh /etc/init.d/h2-gateway
sudo chmod +x /etc/init.d/h2-gateway
sudo service h2-gateway start || true

if ! grep -q "h2_gateway_daemon.py" /home/ubuntu/.bashrc; then
cat << 'BRC' >> /home/ubuntu/.bashrc
if ! pgrep -f h2_gateway_daemon.py >/dev/null 2>&1; then
    sudo service h2-gateway start >/dev/null 2>&1 || true
fi
BRC
fi
