#!/bin/bash
chmod 755 /home/ubuntu/*.py /home/ubuntu/*.sh 2>/dev/null || true
echo "file_permissions_fixed=yes"
