#!/usr/bin/env python3
import sys
import urllib.request
import http.cookiejar

print("=== VICTIM ===")
print("Victim chi truy cap trang binh thuong, khong gui payload.")
url = input(
    "Normal portal URL [http://192.168.10.2/page?lang=vi]: "
).strip() or "http://192.168.10.2/page?lang=vi"

confirm = input("Type VISIT to open this normal page: ").strip()
if confirm != "VISIT":
    print("victim_interacted=no")
    print("victim_cookie_received=no")
    sys.exit(0)

jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

try:
    response = opener.open(url, timeout=5)
    headers = response.headers
    cookies = [(c.name, c.value) for c in jar]

    print("\n=== KET QUA REQUEST THAT CUA VICTIM ===")
    print("HTTP status:", response.status)
    print("Cache status:", headers.get("X-Lab-Cache"))
    print("Content-Language:", headers.get("Content-Language"))
    print("Set-Cookie:", headers.get("Set-Cookie"))
    print("Cookie trong trinh duyet victim:", cookies)

    got_admin = any(name == "admin_access" and value == "true" for name, value in cookies)

    print("\n=== GIAI THICH ===")
    if headers.get("X-Lab-Cache") == "HIT":
        print("Gateway tra response cu tu cache.")
    else:
        print("Gateway khong tra response tu cache.")

    if got_admin:
        print("Victim nhan admin_access=true tu response cache da bi dau doc.")
    else:
        print("Victim khong nhan duoc admin_access=true.")

    print("victim_interacted=yes")
    print("victim_cookie_received=yes" if got_admin else "victim_cookie_received=no")

except Exception as error:
    print("victim_error=%s" % error)
    print("victim_interacted=no")
    print("victim_cookie_received=no")
