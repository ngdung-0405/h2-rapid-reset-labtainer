#!/bin/bash
sudo cp /home/ubuntu/h2reset.py /usr/local/bin/h2reset
sudo chmod +x /usr/local/bin/h2reset /home/ubuntu/h2reset.py
chmod 644 /home/ubuntu/attack_notes.txt 2>/dev/null || true
