Run manually:
./run_attacker.sh

When prompted, type:
POISON
