#!/usr/bin/env python3
import json
p="/home/ubuntu/target-metrics.json"
try:
    data=json.load(open(p))
except Exception:
    data={}
print("=== TARGET-WEB METRICS ===")
for k,v in data.items():
    print(f"{k}: {v}")
if data.get("slow_cancelled", 0) > 0:
    print("target_request_cancelled=yes")
else:
    print("target_request_cancelled=no")
