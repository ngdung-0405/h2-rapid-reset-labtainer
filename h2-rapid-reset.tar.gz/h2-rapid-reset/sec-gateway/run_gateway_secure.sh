#!/bin/bash
set -e
cd /home/ubuntu
test -f gateway.crt || { echo "Chạy ./run_gateway.sh trước"; exit 1; }
echo "gateway_secure_started=yes"
echo "GATEWAY_MODE=secure"
exec env GATEWAY_MODE=secure python3 /home/ubuntu/h2_gateway.py
