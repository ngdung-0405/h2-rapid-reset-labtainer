#!/bin/sh
### BEGIN INIT INFO
# Provides:          h2-gateway
# Required-Start:    $network
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: HTTP/2 Reverse Proxy & Rapid Reset Protection Daemon
### END INIT INFO

DAEMON="/usr/local/bin/h2_gateway_daemon.py"
PIDFILE="/var/run/h2-gateway.pid"

case "$1" in
  start)
    echo "Starting h2-gateway..."
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "h2-gateway is already running."
        exit 0
    fi
    nohup /usr/bin/python3 "$DAEMON" >/var/log/h2-gateway/daemon.err 2>&1 &
    echo $! > "$PIDFILE"
    ;;
  stop)
    echo "Stopping h2-gateway..."
    if [ -f "$PIDFILE" ]; then
        kill $(cat "$PIDFILE") 2>/dev/null
        rm -f "$PIDFILE"
    fi
    pkill -f h2_gateway_daemon.py 2>/dev/null || true
    ;;
  restart)
    $0 stop
    sleep 1
    $0 start
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "h2-gateway is running (PID $(cat $PIDFILE))"
    else
        echo "h2-gateway is stopped"
        exit 1
    fi
    ;;
  *)
    echo "Usage: service h2-gateway {start|stop|restart|status}"
    exit 1
    ;;
esac
exit 0
