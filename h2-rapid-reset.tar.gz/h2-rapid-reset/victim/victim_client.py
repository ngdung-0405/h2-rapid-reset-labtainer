#!/usr/bin/env python3
import socket
import ssl
import time
from h2.config import H2Configuration
from h2.connection import H2Connection
from h2.events import ResponseReceived, DataReceived, StreamEnded

HOST="192.168.10.2"
PORT=8443

print("=== VICTIM HTTP/2 CLIENT ===")
path=input("Nhập endpoint cần truy cập [/api/catalog]: ").strip()

if path != "/api/catalog":
    raise SystemExit("Victim chỉ được truy cập endpoint an toàn /api/catalog")

ctx=ssl.create_default_context()
ctx.check_hostname=False
ctx.verify_mode=ssl.CERT_NONE
ctx.set_alpn_protocols(["h2"])

started=time.monotonic()
raw=socket.create_connection((HOST,PORT), timeout=5)
sock=ctx.wrap_socket(raw, server_hostname="portal.lab")

if sock.selected_alpn_protocol() != "h2":
    raise SystemExit("Không dùng được HTTP/2.")

h2=H2Connection(H2Configuration(client_side=True, header_encoding="utf-8"))
h2.initiate_connection()
sock.sendall(h2.data_to_send())

sid=h2.get_next_available_stream_id()
h2.send_headers(sid, [
    (":method","GET"),
    (":scheme","https"),
    (":authority","portal.lab"),
    (":path",path)
], end_stream=True)
sock.sendall(h2.data_to_send())

headers={}
body=b""
finished=False

while not finished:
    data=sock.recv(65535)
    if not data:
        break
    for ev in h2.receive_data(data):
        if isinstance(ev, ResponseReceived):
            headers=dict(ev.headers)
        elif isinstance(ev, DataReceived):
            body += ev.data
            h2.acknowledge_received_data(ev.flow_controlled_length, ev.stream_id)
        elif isinstance(ev, StreamEnded):
            finished=True
    pending=h2.data_to_send()
    if pending:
        sock.sendall(pending)

elapsed=(time.monotonic()-started)*1000
sock.close()

status=headers.get(":status","0")
mode=headers.get("x-lab-mode","unknown")

print(f"HTTP status: {status}")
print(f"Gateway mode: {mode}")
print(f"Response time: {elapsed:.1f} ms")
print("Response body:", body.decode(errors="replace"))

if status == "200" and mode == "vulnerable":
    print("victim_baseline_complete=yes")

if status == "200" and mode == "secure" and elapsed < 1500:
    print("victim_stable_after_fix=yes")
