#!/bin/bash
echo "TARGET WEB SECURE MODE RUNNING"
sudo env APP_MODE=secure python3 /home/ubuntu/target_server.py
