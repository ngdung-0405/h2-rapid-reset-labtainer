#!/usr/bin/env python3
import json
import os
import socket
import ssl
import threading
import time
import http.client
from collections import deque
from h2.config import H2Configuration
from h2.connection import H2Connection
from h2.events import RequestReceived, StreamReset
from h2.errors import ErrorCodes

MODE = os.environ.get("GATEWAY_MODE", "vulnerable")
METRICS = "/home/ubuntu/h2-gateway-metrics.json"
EVENTS = "/home/ubuntu/gateway-events.log"
RST_LIMIT = 10
RST_WINDOW = 2.0

LOCK = threading.RLock()
metrics = {
    "mode": MODE,
    "streams_opened": 0,
    "stream_resets": 0,
    "backend_cancelled": 0,
    "secure_limit_triggered": False
}

def save():
    with LOCK:
        with open(METRICS, "w") as f:
            json.dump(metrics, f)

def event(text):
    line = time.strftime("%Y-%m-%dT%H:%M:%S") + " " + text
    print("[gateway] " + line, flush=True)
    with open(EVENTS, "a") as f:
        f.write(line + "\n")

def backend_get(path):
    try:
        c = http.client.HTTPConnection("172.20.0.10", 8080, timeout=3)
        c.request("GET", path)
        r = c.getresponse()
        data = r.read()
        c.close()
        return r.status, data
    except Exception as e:
        return 502, str(e).encode()

def cancel_backend(sid):
    backend_get("/lab/cancel?stream_id=" + str(sid))
    with LOCK:
        metrics["backend_cancelled"] += 1
        save()

class Session:
    def __init__(self, sock):
        self.sock = sock
        self.h2 = H2Connection(H2Configuration(client_side=False, header_encoding="utf-8"))
        self.send_lock = threading.Lock()
        self.reset_times = deque()
        self.closed = False
        self.active = {}

    def flush(self):
        payload = self.h2.data_to_send()
        if payload:
            self.sock.sendall(payload)

    def reply(self, sid, status, body):
        try:
            with self.send_lock:
                if sid not in self.active or self.active[sid].get("reset"):
                    return
                headers = [
                    (":status", str(status)),
                    ("content-type", "application/json"),
                    ("x-lab-mode", MODE)
                ]
                self.h2.send_headers(sid, headers)
                self.h2.send_data(sid, body, end_stream=True)
                self.flush()
        except Exception:
            pass

    def do_request(self, sid, path):
        if path.startswith("/api/catalog"):
            status, body = backend_get("/api/catalog")
            self.reply(sid, status, body)
            return

        if path.startswith("/lab/slow-read"):
            status, body = backend_get("/lab/slow-read?stream_id=" + str(sid))
            self.reply(sid, status, body)
            return

        self.reply(sid, 404, b'{"error":"unknown endpoint"}')

    def reset_seen(self, sid):
        self.active.setdefault(sid, {})["reset"] = True
        event(f"RST_STREAM stream={sid}")

        with LOCK:
            metrics["stream_resets"] += 1
            save()

        threading.Thread(target=cancel_backend, args=(sid,), daemon=True).start()

        if MODE != "secure":
            return

        now = time.time()
        self.reset_times.append(now)
        while self.reset_times and now - self.reset_times[0] > RST_WINDOW:
            self.reset_times.popleft()

        if len(self.reset_times) > RST_LIMIT and not self.closed:
            self.closed = True
            with LOCK:
                metrics["secure_limit_triggered"] = True
                save()
            event("GOAWAY ENHANCE_YOUR_CALM reset-rate-limit")
            try:
                with self.send_lock:
                    self.h2.close_connection(
                        error_code=ErrorCodes.ENHANCE_YOUR_CALM,
                        additional_data=b"rapid-reset limit"
                    )
                    self.flush()
            except Exception:
                pass

    def run(self):
        with self.send_lock:
            self.h2.initiate_connection()
            self.flush()

        while not self.closed:
            try:
                data = self.sock.recv(65535)
                if not data:
                    break
                events = self.h2.receive_data(data)
                for ev in events:
                    if self.closed:
                        break
                    if isinstance(ev, RequestReceived):
                        headers = dict(ev.headers)
                        path = headers.get(":path", "/")
                        sid = ev.stream_id
                        self.active[sid] = {"reset": False, "path": path}

                        with LOCK:
                            metrics["streams_opened"] += 1
                            save()

                        event(f"STREAM_OPEN stream={sid} path={path}")
                        threading.Thread(
                            target=self.do_request,
                            args=(sid, path),
                            daemon=True
                        ).start()

                    elif isinstance(ev, StreamReset):
                        self.reset_seen(ev.stream_id)

                with self.send_lock:
                    self.flush()
            except Exception:
                break

        self.sock.close()

def serve():
    cert="/home/ubuntu/gateway.crt"
    key="/home/ubuntu/gateway.key"

    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert, key)
    ctx.set_alpn_protocols(["h2"])

    raw=socket.socket()
    raw.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    raw.bind(("0.0.0.0", 8443))
    raw.listen(30)

    print(f"gateway_mode={MODE}", flush=True)
    print("gateway_h2_tls_ready=yes", flush=True)
    save()

    while True:
        client,_=raw.accept()
        try:
            tls=ctx.wrap_socket(client, server_side=True)
            if tls.selected_alpn_protocol() != "h2":
                tls.close()
                continue
            threading.Thread(target=Session(tls).run, daemon=True).start()
        except Exception:
            client.close()

serve()
